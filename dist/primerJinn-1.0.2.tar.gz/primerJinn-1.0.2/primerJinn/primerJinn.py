#!/bin/python
import os

def main():
    print("Welcome to primerJinn")
    print("")
    os.system('getMultiPrimerSet')
    print("")
    os.system('PCRinSilico')

if __name__ == '__main__':
    main()